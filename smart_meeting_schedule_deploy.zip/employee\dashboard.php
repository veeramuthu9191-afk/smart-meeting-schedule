<!DOCTYPE html>
<html>

<head>

<title>Employee Dashboard</title>

<link rel="stylesheet" href="dashboard.css">

</head>


<body>


<h1>Employee Dashboard</h1>


<div class="dashboard-container">


    <div class="card">
    <h3>My Meetings</h3>
    <p>View upcoming meetings</p>

    <a href="my_meetings.php">
        <button>View Meetings</button>
    </a>

</div>


    <div class="card">
    <h3>Notifications</h3>
    <p>Meeting reminders and alerts</p>
    <button onclick="window.location.href='notifications.php'">
        View Notifications
    </button>
</div>


    <div class="card">
    <h3>My Tasks</h3>
    <p>Check assigned tasks</p>

    <button onclick="window.location.href='my_tasks.php'">
        View Tasks
    </button>
</div>


    <div class="card">
    <h3>My Profile</h3>
    <p>View employee details</p>
    <button onclick="window.location.href='profile.php'">View Profile</button>
  </div>

</div>


</body>

</html>